﻿namespace ConsoleApplication1
{
    using System;

    internal class Program
    {
        private static void Main(string[] args)
        {
            Console.WriteLine("Voer uw naam in");
            string input = Console.ReadLine();
            Console.WriteLine("Hallo " + input + "! ");
            Console.ReadKey();
        }
    }
}
