﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Opdracht2
{
    enum Color
    {
        Black,
        White,
        Blue
    }
}
