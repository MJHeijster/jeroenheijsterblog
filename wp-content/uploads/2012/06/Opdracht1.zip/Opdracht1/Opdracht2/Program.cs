﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Opdracht2
{
    class Program
    {
        static void Main(string[] args)
        {
            Rectangle rectangle = new Rectangle();
            rectangle.Width = 2;
            rectangle.Height = 3;
            string color = Color.Blue.ToString();
            Console.Write("The area of the " + color + " rectangle is: " + rectangle.Area);
            Console.ReadKey();
        }
    }
}
