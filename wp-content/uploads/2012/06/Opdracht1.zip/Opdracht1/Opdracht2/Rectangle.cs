﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Opdracht2
{
    class Rectangle
    {

        /// <summary>
        /// Get or set the height of the rectangle
        /// </summary>
        public int Height
        {
            get;
            set;
        }
        /// <summary>
        /// Get or set the width of the rectangle
        /// </summary>
        public int Width
        {
            get;
            set;
        }
        /// <summary>
        /// Get the area of the rectangle
        /// </summary>
        public int Area
        {
            get
            {
              return Width * Height;
            }
        }
    }
}
