This plugin will show a warning to the user that this site uses cookies. If the user clicks "yes" a cookie will be placed that he agrees. If not, he/she can't 
browse the site.

Installation:
Place the folder in the zip in your wp-content/plugins/ folder or use your admin console.